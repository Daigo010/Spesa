package com.example.spesadioggi;
import android.Manifest; import android.app.*; import android.os.*; import android.content.*; import android.content.pm.PackageManager; import android.graphics.Color; import android.speech.*; import android.view.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 LinearLayout list,bought; TextView status;
 int blue=Color.rgb(185,221,240);
 public void onCreate(Bundle b){super.onCreate(b); if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},9); build();}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.BLACK);v.setTextSize(z);v.setPadding(18,18,18,18);return v;}
 void build(){ScrollView sv=new ScrollView(this); LinearLayout a=new LinearLayout(this);a.setOrientation(LinearLayout.VERTICAL);a.setPadding(16,22,16,28);a.setBackgroundColor(blue);
 TextView h=t("🛒  Spesa di Oggi",30);h.setGravity(17);a.addView(h);
 Button mic=new Button(this);mic.setText("🎙️  PARLA");mic.setTextSize(21);a.addView(mic,new LinearLayout.LayoutParams(-1,80));status=t("Tocca il microfono e detta uno o più prodotti.",15);status.setGravity(17);a.addView(status);
 a.addView(t("DA COMPRARE",19)); list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);a.addView(list);
 String[] ex={"2 confezioni di pasta Barilla Penne Rigate da 500 g","Latte parzialmente scremato","Mozzarella Santa Lucia","1 kg di patate"}; for(String x:ex)addItem(x,list,false);
 a.addView(t("COMPRATI",19)); bought=new LinearLayout(this);bought.setOrientation(LinearLayout.VERTICAL);a.addView(bought);setContentView(sv);sv.addView(a);
 mic.setOnClickListener(v->listen());}
 void addItem(String s,LinearLayout target,boolean done){TextView v=t("☐  "+s,19);v.setBackgroundColor(Color.WHITE);v.setOnClickListener(x->{if(target==list){list.removeView(v);v.setText("✓  "+s);bought.addView(v);}else{bought.removeView(v);v.setText("☐  "+s);list.addView(v);}});target.addView(v,new LinearLayout.LayoutParams(-1, -2));}
 void listen(){status.setText("🎙️  Ti ascolto…");Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"it-IT");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Dimmi cosa devo aggiungere alla spesa");try{startActivityForResult(i,10);}catch(Exception e){status.setText("Riconoscimento vocale non disponibile.");}}
 protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty()){String s=x.get(0);addItem(s,list,false);status.setText("Aggiunto: "+s);}}}
}